npm --version
uptime
pwd
